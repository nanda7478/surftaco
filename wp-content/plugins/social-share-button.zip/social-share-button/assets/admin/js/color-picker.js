	jQuery(document).ready(function($)
		{	


			$('.bg_color').wpColorPicker();
					
					


		});