<?php
/*
* @Author 		ParaTheme
* Copyright: 	2015 ParaTheme
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 

$html_first.= '<span class="button-icon"><i class="fa fa-'.$site_info['icon'].'"></i></span>';